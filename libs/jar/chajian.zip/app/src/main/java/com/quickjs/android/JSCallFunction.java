package com.quickjs.android;

public interface JSCallFunction {

    Object call(Object... args);

}
